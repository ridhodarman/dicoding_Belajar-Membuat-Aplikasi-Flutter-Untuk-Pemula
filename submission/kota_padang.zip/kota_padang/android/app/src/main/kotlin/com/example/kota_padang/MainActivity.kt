package com.example.kota_padang

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
