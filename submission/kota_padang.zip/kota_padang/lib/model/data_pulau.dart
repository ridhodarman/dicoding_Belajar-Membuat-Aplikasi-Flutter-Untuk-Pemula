class DataPulau {
  String name;
  String kecamatan;
  String description;
  String koordinat;
  String area;
  String foto;
  List<String> imagePulaus;

  DataPulau({
    this.name,
    this.kecamatan,
    this.description,
    this.koordinat,
    this.area,
    this.foto,
    this.imagePulaus,
  });
}
